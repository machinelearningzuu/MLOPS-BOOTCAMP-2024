with open('src/VERSION', 'r') as f:
    __version__ = f.read().strip()